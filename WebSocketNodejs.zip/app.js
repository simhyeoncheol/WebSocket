const express = require("express");
const http = require("http");
const WebSocket = require("ws");

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

let clients = new Map(); // 사용자 ID와 WebSocket 객체를 매핑하는 맵

wss.on("connection", (ws) => {
    console.log("웹소켓 클라이언트가 연결되었습니다.");

    // 사용자에게 고유한 ID 할당
    const userId = generateUserId();
    clients.set(userId, ws);

    // 연결된 모든 클라이언트에게 사용자 수 업데이트 전송
    broadcastUserCount();

    ws.on("message", (message) => {
        // 연결된 모든 클라이언트에게 메시지 전송
        wss.clients.forEach((client) => {
            if (client.readyState === WebSocket.OPEN) {
                client.send(userId+"님이 보낸 메세지 : "+message);
            }
        });
    });

    ws.on("close", () => {
        console.log("웹소켓 클라이언트와의 연결이 해제되었습니다.");
        clients.delete(userId); // 연결이 해제된 사용자 제거
        broadcastUserCount(); // 사용자 수 업데이트 전송
    });
});

function generateUserId() {
    return Math.random().toString(36).substr(2, 9); // 간단한 랜덤 ID 생성
}

function broadcastUserCount() {
    // 연결된 모든 클라이언트에게 사용자 수 업데이트 전송
    wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
            const userCountMessage = clients.size + "명의 사용자가 접속중입니다.";
            client.send(userCountMessage);
        }
    });
}

server.listen(3001, () => {
    console.log("웹소켓 서버가 포트 3001에서 실행 중입니다.");
});
